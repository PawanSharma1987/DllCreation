#include "math.h"

extern "C"
{
	int __stdcall add(int x, int y)
	{
		return x + y;
	}
	int __stdcall sub(int x, int y)
	{
		return x - y;
	}
}