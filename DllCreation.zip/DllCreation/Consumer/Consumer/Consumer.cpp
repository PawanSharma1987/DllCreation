// Consumer.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "math.h"
#include <iostream>
#include <Windows.h>
using namespace std;

typedef int(__stdcall *FUNPTR)(int, int);
FUNPTR fptr = nullptr;
int main()
{
	HMODULE hmod = ::LoadLibrary(L"dllwriting.dll");
	
	fptr = (FUNPTR)GetProcAddress(hmod, "add");
	cout << fptr(10, 20) << endl;

	fptr = (FUNPTR)GetProcAddress(hmod, "sub");
	cout << fptr(10, 20) << endl;
	FreeLibrary(hmod);
	cin.get();
    return 0;
}

