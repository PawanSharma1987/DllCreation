//#pragma once
#ifndef _MATHGUI_H
#define _MATHGUI_H
#ifdef __cplusplus
extern "C"
{
	int __stdcall add(int x, int y);
	int __stdcall sub(int x, int y);
}
#else
int __stdcall add(int x, int y);
int __stdcall sub(int x, int y);
#endif
#endif




